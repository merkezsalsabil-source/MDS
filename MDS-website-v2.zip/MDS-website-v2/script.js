// MDS — interactions and GSAP scroll experience

// Mobile navigation
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton?.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(opened));
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
}));

// Reveal elements on entry
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
} else {
  document.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
}

// 3D tilt on service cards
if (window.matchMedia('(pointer:fine)').matches && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.querySelectorAll('[data-tilt]').forEach(card => {
    card.addEventListener('pointermove', e => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `perspective(900px) rotateY(${x * 5}deg) rotateX(${-y * 5}deg) translateY(-3px)`;
    });
    card.addEventListener('pointerleave', () => { card.style.transform = ''; });
  });
}

// Hero parallax
const heroVisual = document.querySelector('.hero-visual');
if (heroVisual && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  window.addEventListener('scroll', () => {
    if (window.innerWidth < 701) return;
    heroVisual.style.marginTop = `${Math.min(window.scrollY, 500) * 0.10}px`;
  }, { passive: true });
}

// GSAP layered parallax: independent from the rest of the page
function initMdsScrollExperience() {
  const section = document.querySelector('.mds-scroll-experience');
  const arrowButton = document.querySelector('#arrow-btn');
  if (!section) return;

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const gsapReady = window.gsap && window.ScrollTrigger;

  if (gsapReady && !reducedMotion) {
    gsap.registerPlugin(ScrollTrigger);
    if (window.ScrollToPlugin) gsap.registerPlugin(ScrollToPlugin);

    const timeline = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1.1,
        invalidateOnRefresh: true
      }
    });

    timeline
      .fromTo('.parallax-sky', { y: 0, scale: 1.08 }, { y: -100, scale: 1.18, ease: 'none' }, 0)
      .fromTo('.parallax-grid', { y: 0 }, { y: 150, ease: 'none' }, 0)
      .fromTo('.orb-back', { y: 40, x: 0, rotation: 0 }, { y: -180, x: -55, rotation: 55, ease: 'none' }, 0)
      .fromTo('.cloud-left', { y: 100, x: 0 }, { y: -390, x: -70, ease: 'none' }, 0)
      .fromTo('.cloud-right', { y: -80, x: 0 }, { y: -440, x: 80, ease: 'none' }, 0)
      .fromTo('.panel-back', { y: 80, rotationY: -18, rotationZ: 8 }, { y: -250, rotationY: 12, rotationZ: -4, ease: 'none' }, 0)
      .fromTo('.panel-front', { y: 120, rotationY: -17, rotationX: 5, rotationZ: -5, scale: .82 }, { y: -170, rotationY: 10, rotationX: -2, rotationZ: 3, scale: 1.08, ease: 'none' }, 0)
      .fromTo('.orb-front', { y: 100, x: 40, scale: .65 }, { y: -350, x: -130, scale: 1.3, ease: 'none' }, 0)
      .fromTo('.chip-one', { y: 100, rotation: 7 }, { y: -370, rotation: -8, ease: 'none' }, 0)
      .fromTo('.chip-two', { y: -40, rotation: -6 }, { y: -280, rotation: 8, ease: 'none' }, 0)
      .fromTo('.parallax-title', { y: 0, opacity: 1 }, { y: -130, opacity: .15, ease: 'none' }, 0);

    arrowButton?.addEventListener('pointerenter', () => {
      gsap.to('.parallax-arrow .arrow', { y: 9, duration: .45, ease: 'back.out(3)', overwrite: 'auto' });
    });
    arrowButton?.addEventListener('pointerleave', () => {
      gsap.to('.parallax-arrow .arrow', { y: 0, duration: .35, ease: 'power2.out', overwrite: 'auto' });
    });
    arrowButton?.addEventListener('click', () => {
      const target = document.querySelector('#services');
      if (target && window.ScrollToPlugin) {
        gsap.to(window, { scrollTo: { y: target, offsetY: 20 }, duration: 1.25, ease: 'power2.inOut' });
      } else if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });

    window.addEventListener('load', () => ScrollTrigger.refresh(), { once: true });
  } else {
    // Graceful fallback: no external animation library required.
    arrowButton?.addEventListener('click', () => {
      document.querySelector('#services')?.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth' });
    });
  }
}

// Defer until external GSAP scripts (also deferred) are available.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initMdsScrollExperience, { once: true });
} else {
  initMdsScrollExperience();
}

document.body.classList.add('page-loaded');
console.log('%c MDS — MUAWIYA DIGITAL SERVICE ', 'background:#101827;color:#6ce4ef;padding:12px;font-weight:bold;');


// MDS curved SVG typography: move the sentence along its path as this section scrolls.
(() => {
  const section = document.querySelector('#mds-type-scroll');
  const textPath = document.querySelector('#mds-type-textpath');
  if (!section || !textPath) return;

  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion) {
    textPath.setAttribute('startOffset', '32%');
    return;
  }

  let frame = 0;
  const updateTextPath = () => {
    const bounds = section.getBoundingClientRect();
    const scrollableDistance = Math.max(1, bounds.height - window.innerHeight);
    const progress = Math.min(1, Math.max(0, -bounds.top / scrollableDistance));
    const offset = 90 - progress * 95;
    textPath.setAttribute('startOffset', `${offset.toFixed(2)}%`);
    frame = 0;
  };

  const requestUpdate = () => {
    if (frame) return;
    frame = window.requestAnimationFrame(updateTextPath);
  };

  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', requestUpdate, { passive: true });
  updateTextPath();
})();


// MDS depth studies: GSAP scroll parallax for the layered composition.
(() => {
  const section = document.querySelector('#mds-depth-scroll');
  if (!section) return;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduceMotion || !window.gsap || !window.ScrollTrigger) return;

  gsap.registerPlugin(ScrollTrigger);
  const pin = section.querySelector('.mds-depth-pin');
  const giant = section.querySelector('.mds-depth-giant');
  const card = section.querySelector('.mds-depth-card');
  const foreground = section.querySelector('.mds-depth-front');
  const orbits = section.querySelectorAll('.mds-depth-orbit');

  const depthTimeline = gsap.timeline({
    scrollTrigger: {
      trigger: section,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 1,
      invalidateOnRefresh: true
    }
  });

  depthTimeline
    .fromTo(giant, { y: 125, scale: .92 }, { y: -145, scale: 1.12, ease: 'none' }, 0)
    .fromTo(card, { y: 85, rotation: -8, scale: .82, rotateY: -16 }, { y: -95, rotation: 4, scale: 1.04, rotateY: 12, ease: 'none' }, 0)
    .fromTo(foreground, { y: 65, opacity: 1 }, { y: -110, opacity: .35, ease: 'none' }, 0)
    .fromTo(orbits[0], { y: 70, rotation: -22 }, { y: -130, rotation: 18, ease: 'none' }, 0)
    .fromTo(orbits[1], { y: -45, rotation: 48 }, { y: 125, rotation: 88, ease: 'none' }, 0);

  window.addEventListener('load', () => ScrollTrigger.refresh(), { once: true });
})();


// MDS editorial masked-line reveals — animate each panel when it enters view.
(() => {
  const panels = document.querySelectorAll('.reveal-lines');
  if (!panels.length) return;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reducedMotion || !('IntersectionObserver' in window)) {
    panels.forEach(panel => panel.classList.add('is-visible'));
    return;
  }
  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, {threshold:0.28});
  panels.forEach(panel => observer.observe(panel));
})();


// MDS cursor spotlight: reveal the brighter duplicate text under the pointer.
(() => {
  const stage = document.querySelector('#mds-spotlight-stage');
  if (!stage) return;
  const finePointer = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!finePointer || reducedMotion) {
    stage.style.setProperty('--mds-spot-radius', '180px');
    stage.style.setProperty('--mds-mx', '50%');
    stage.style.setProperty('--mds-my', '50%');
    return;
  }
  stage.addEventListener('pointermove', event => {
    const rect = stage.getBoundingClientRect();
    stage.style.setProperty('--mds-mx', `${event.clientX - rect.left}px`);
    stage.style.setProperty('--mds-my', `${event.clientY - rect.top}px`);
  });
  stage.addEventListener('pointerleave', () => {
    stage.style.setProperty('--mds-mx', '50%');
    stage.style.setProperty('--mds-my', '50%');
  });
})();


// MDS project configurator — estimate only; no payment details are collected.
(() => {
  const root = document.querySelector('.mds-checkout');
  if (!root) return;
  const money = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const packageNames = { landing: 'Landing page', vitrine: 'Site vitrine', ecommerce: 'Site e-commerce', portfolio: 'Portfolio' };
  const radios = [...root.querySelectorAll('input[name="mds-package"]')];
  const addons = [...root.querySelectorAll('[data-addon]')];
  const total = root.querySelector('#mds-estimate');
  const selected = root.querySelector('#mds-selected-name');
  const count = root.querySelector('#mds-options-count');
  function update() {
    const active = radios.find(r => r.checked);
    radios.forEach(r => r.closest('.mds-package').classList.toggle('is-selected', r.checked));
    const chosen = addons.filter(a => a.checked);
    const amount = Number(active?.dataset.price || 0) + chosen.reduce((sum, a) => sum + Number(a.dataset.price || 0), 0);
    selected.textContent = packageNames[active?.value] || 'Projet personnalisé';
    count.textContent = chosen.length ? chosen.length + ' option' + (chosen.length > 1 ? 's' : '') : 'Aucune';
    total.textContent = money.format(amount) + (chosen.some(a => a.dataset.addon === 'maintenance') ? ' + /mois' : '');
  }
  radios.concat(addons).forEach(input => input.addEventListener('change', update));
  update();
})();
