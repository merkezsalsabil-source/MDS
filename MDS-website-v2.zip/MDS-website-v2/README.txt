MDS — MUAWIYA DIGITAL SERVICE
============================

Fichiers :
- index.html : structure et contenu du site
- style.css : identité visuelle, responsive, animations et effets lumineux
- script.js : interactions, animations au scroll et suivi du curseur

Nouveautés :
- Effet spotlight : le curseur révèle une copie lumineuse du texte.
- Faisceau lumineux animé qui balaie un grand titre MDS.
- Adaptation mobile et prise en compte de prefers-reduced-motion.

Prévisualisation : ouvrir index.html dans un navigateur moderne.
Les polices Google Fonts et les bibliothèques GSAP chargent via Internet.
